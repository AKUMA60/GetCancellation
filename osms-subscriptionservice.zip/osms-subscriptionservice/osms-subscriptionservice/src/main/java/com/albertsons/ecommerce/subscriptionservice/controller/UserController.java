package com.albertsons.ecommerce.subscriptionservice.controller;

public class UserController {

}
