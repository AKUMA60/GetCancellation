package com.albertsons.ecommerce.subscriptionservice.model;

public class UserSubscription {

	
}
