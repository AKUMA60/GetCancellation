package com.albertsons.ecommerce.subscriptionsservice.osmssubscriptionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OsmsSubscriptionserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
